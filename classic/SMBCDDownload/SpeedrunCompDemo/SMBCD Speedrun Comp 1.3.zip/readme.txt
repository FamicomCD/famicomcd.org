https://famicomcd.github.io/speedrun

Submit your runs here!:
https://discord.gg/wpSGt5aTuw\
famicomcd@gmail.com