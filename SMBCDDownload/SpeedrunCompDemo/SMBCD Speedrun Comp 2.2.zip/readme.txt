https://famicomcd.org/smbcd/speedrun


Press L and R to restart speedruns. 





Submit your runs here!:

https://discord.gg/wpSGt5aTuw/
support@famicomcd.org