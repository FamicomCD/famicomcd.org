https://famicomcd.github.io/speedrun

Press L and R to restart speedruns.

Submit your runs here:
https://discord.gg/famicomcd/
or
https://discord.gg/wpSGt5aTuw/


famicomcd@gmail.com