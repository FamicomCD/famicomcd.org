https://famicomcd.org/smbcd/speedrun

Submit your runs here!:
https://discord.gg/wpSGt5aTuw\
support@famicomcd.org